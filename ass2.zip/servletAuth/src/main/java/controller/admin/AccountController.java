package controller.admin;
import java.io.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "AccountController", value = "/account")
public class AccountController extends HttpServlet {
    public AccountController() {
        super();
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if(username.equalsIgnoreCase("admin") && password.equalsIgnoreCase("123")) {
            HttpSession session = request.getSession();
            session.setAttribute("username", username);
            request.getRequestDispatcher("listProducts.jsp").forward(request, response);
        } else {
            request.setAttribute("message", "Account's Invalid");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null)
            request.getRequestDispatcher("login.jsp").forward(request, response);
        else if (action.equalsIgnoreCase("logout")) {
            HttpSession session = request.getSession();
            session.removeAttribute("username");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
