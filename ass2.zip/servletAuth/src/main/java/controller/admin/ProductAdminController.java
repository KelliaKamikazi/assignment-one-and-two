package controller.admin;

import java.io.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "ProductController", value = "/admin-product")
public class ProductAdminController extends HttpServlet {
    public ProductAdminController() {
        super();
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("listProducts.jsp").forward(request, response);
    }
}
